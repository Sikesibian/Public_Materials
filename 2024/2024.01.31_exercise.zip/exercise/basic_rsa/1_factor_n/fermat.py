def fermat(n: int):
    pass