def rabin(c, p, q):
    pass