def my_gcd(a: int, b: int):
    pass

def my_extgcd(a: int, b: int):
    pass

def my_extgcd_nonrecursive(a: int, b: int):
    pass

def my_extgcd_matrix(a: int, b: int):
    pass

# `pass` means `TODO`