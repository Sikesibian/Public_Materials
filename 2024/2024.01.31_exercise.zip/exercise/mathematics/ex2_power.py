def my_fast_power(a: int, e: int, n: int):
    # a: base, e: exponent, n: modulus
    pass

def my_inverse_mod(a: int, n: int):
    # gcd(a, n) == 1?
    pass

# `pass` means `TODO`