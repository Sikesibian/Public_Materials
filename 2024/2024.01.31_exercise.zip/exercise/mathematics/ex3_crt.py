def my_crt(a_s: list, n_s: list):
    # a_s: remainders, n_s: modulus
    pass

# `pass` means `TODO`