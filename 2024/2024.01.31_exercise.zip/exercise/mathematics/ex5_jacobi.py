def my_jacobi(m: int, n: int):
    if m % 2 == 0 or n % 2 == 0 :
        pass
    elif m > 0 and n > 0:
        pass
    elif m * n < 0:
        pass
    elif m < 0 and n < 0:
        pass
    pass

# `pass` means `TODO`