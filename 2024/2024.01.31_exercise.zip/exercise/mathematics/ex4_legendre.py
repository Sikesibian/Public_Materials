from Crypto.Util.number import isPrime
def my_legendre(a, p):
    pass

# `pass` means `TODO`